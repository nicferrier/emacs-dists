#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/d/usr/lib"
XML2_LIBS="-lxml2 -lz   -liconv  "
XML2_INCLUDEDIR="-I/d/usr/include/libxml2"
MODULE_VERSION="xml2-2.7.8"

