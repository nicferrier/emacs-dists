module MessagePack
	VERSION = "0.5.11"
end
