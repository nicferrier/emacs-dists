$:.unshift File.dirname(__FILE__)

require 'util/file_cache_map_test'
require 'util/pattern_matcher_test'

