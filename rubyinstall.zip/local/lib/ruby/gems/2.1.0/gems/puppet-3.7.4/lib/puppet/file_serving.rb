# Just a stub class.
class Puppet::FileServing # :nodoc:
end
